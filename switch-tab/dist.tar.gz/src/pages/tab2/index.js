Page({
  onTap() {
    my.switchTab({
      url: 'pages/tab1/index'
    })
  }
});