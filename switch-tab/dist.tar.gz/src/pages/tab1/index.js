Page({
  onTap() {
    my.switchTab({
      url: 'pages/tab2/index'
    })
  }
});