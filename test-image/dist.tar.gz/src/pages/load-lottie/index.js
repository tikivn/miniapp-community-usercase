Page({
  speed: 1
});